package tuan1.btnhom.ltdd3.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btn_co, btn_tr, btn_nh, btn_ch, btn_bang, btn_cl;
    TextView value;
    int temp = 0, num1 = 0, num2 = 0, num3 = 0;
    int method = -1; // 1 cong - 2 tru - 3 nhan - 4 chia

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        controller();
        setEvent();
    }

    private void push(int num) {
        if (temp == 0 && method == 0) {
            clear();
        }
        temp = temp * 10 + num;
        load();
    }

    private void setmethod(int key) {
        if (num1 != 0) {
            if (num2 != 0 && num3 != 0) {
                num1 = num3;
            }
            temp = 0;
            method = key;
            load();
        }
    }

    private String getmethod(int md) {
        String m = "";
        switch (md) {
            case 1:
                m = "+";
                break;
            case 2:
                m = "-";
                break;
            case 3:
                m = "*";
                break;
            case 4:
                m = "/";
                break;
        }
        return m;
    }

    private void load() {
        try {
            if (method < 0) {
                num1 = temp;
                value.setText("" + temp);
            } else if (method > 0 && method <= 4) {
                num2 = temp;
                value.setText(num1 + getmethod(method) + temp);
            }
        } catch (Exception ex) {
            Toast.makeText(this, "" + ex.toString(), Toast.LENGTH_SHORT).show();
        }
    }

    private void clear() {
        temp = 0;
        num1 = 0;
        num2 = 0;
        num3 = 0;
        method = -1;
    }

    private void setEvent() {
        btn_bang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (method > 0 && method <= 4) {
                    switch (method) {
                        case 1:
                            num3 = num1 + num2;
                            break;
                        case 2:
                            num3 = num1 - num2;
                            break;
                        case 3:
                            num3 = num1 * num2;
                            break;
                        case 4:
                            num3 = num1 / num2;
                            break;
                    }
                }
                value.setText(num1 + getmethod(method) + temp + "=" + num3);
                method = 0;
                temp = 0;
            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(0);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(1);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(2);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(3);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(4);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(5);
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(6);
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(7);
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(8);
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(9);
            }
        });
        btn_co.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setmethod(1);
            }
        });
        btn_tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setmethod(2);
            }
        });
        btn_nh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setmethod(3);
            }
        });
        btn_ch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setmethod(4);
            }
        });
        btn_cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
                value.setText("");
            }
        });
    }

    private void controller() {
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btn_co = (Button) findViewById(R.id.btn_co);
        btn_tr = (Button) findViewById(R.id.btn_tr);
        btn_nh = (Button) findViewById(R.id.btn_nh);
        btn_ch = (Button) findViewById(R.id.btn_ch);
        btn_bang = (Button) findViewById(R.id.btn_bang);
        btn_cl = (Button) findViewById(R.id.btn_cl);
        value = (TextView) findViewById(R.id.value);
    }
}
